## Guidelines for OpenAPI Definitions

* [Reuse](REUSE.md) of OpenAPI definitions
* [Extending](EXTENSIONS.md) OpenAPI definitions with custom metadata
