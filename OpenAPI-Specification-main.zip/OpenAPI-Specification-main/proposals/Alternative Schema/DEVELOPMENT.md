## Development Guidelines

TBD

## Specification Driving factors

TBD

## Specification Change Criteria

TBD

## Specification Change Process

TBD

## Tracking Process

* GitHub is the medium of record for all spec designs, use cases, and so on.


## Release Process

TBD

## Draft Features


## Transparency



## Participation



## Community Roles

