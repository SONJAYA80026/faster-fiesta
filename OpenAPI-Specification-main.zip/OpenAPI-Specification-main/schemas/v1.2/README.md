# Swagger Specification JSON Schemas

The work on the JSON Schema for the Swagger Specification was donated to the community by [Francis Galiegue](https://github.com/fge)!

Keep in mind that due to some JSON Schema limitations, not all constraints can be described. The missing constraints will be listed here in the future.
